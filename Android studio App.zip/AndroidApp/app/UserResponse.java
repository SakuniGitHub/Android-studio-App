import java.util.List;

public class UserResponse {
    // UserResponse.java


        private List<User> data;

        // Constructor
        public UserResponse(List<User> data) {
            this.data = data;
        }

        // Getter
        public List<User> getData() {
            return data;
        }

        // Setter (if needed)
        public void setData(List<User> data) {
            this.data = data;
        }
    }


